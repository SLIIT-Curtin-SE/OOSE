package model;

import java.util.*;

/**
 * Represents a product group. Product groups are compared on the basis of 
 * their names.
 */
public class ProductGroup implements Comparable<ProductGroup>, ProductInt
{
    private String name;
    private Set<Product> products;
    private Set<ProductGroup> subGroup;
    private ProductGroup parent;
    
    public ProductGroup(String name, ProductGroup parent)
    {
        this.name = name;
        this.products = new TreeSet<>();
        this.subGroup = new TreeSet<>();
        this.parent = parent;
    }
    
    @Override
    public String getName()
    {
        return name;
    }

    @Override
    public float getPrice()
    {
        return 0;
    }

    @Override
    public int getNumberInStock()
    {
        return 0;
    }
    
    public Set<Product> getProducts()
    {
        return Collections.unmodifiableSet(products);
    }

    public Set<ProductGroup> getSubGroups()
    {
        return Collections.unmodifiableSet(subGroup);
    }

    public void addSubGroup(ProductGroup p)
    {
        subGroup.add(p);
    }

    public ProductGroup getParent()
    {
        return parent;
    }
    
    public boolean hasProduct(Product p)
    {
        return products.contains(p);
    }
    
    public void addProduct(Product p)
    {
        products.add(p);
    }
    
    @Override
    public boolean equals(Object obj)
    {
        boolean eq = false;
        if(obj instanceof ProductGroup)
        {
            eq = name.equals(((ProductGroup)obj).name);
        }
        return eq;
    }
    
    @Override
    public int hashCode()
    {
        return name.hashCode();
    }
    
    @Override
    public int compareTo(ProductGroup group)
    {
        return name.compareTo(group.name);
    }
}

package model;

public interface ProductInt
{
    String getName();
    float getPrice();
    int getNumberInStock();
}
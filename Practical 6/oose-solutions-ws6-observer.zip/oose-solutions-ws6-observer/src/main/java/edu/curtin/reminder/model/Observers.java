package edu.curtin.reminder.model;

public  interface Observers {
    public void update();
}